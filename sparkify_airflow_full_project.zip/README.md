# Sparkify Airflow Final Project - Full Implementation

This package contains a complete implementation of the Udacity Sparkify Airflow final project.
Files included:
- dags/sparkify_dag.py : DAG that orchestrates the ETL
- plugins/operators/*.py : Custom operators (StageToRedshift, LoadFact, LoadDimension, DataQuality)
- plugins/helpers/sql_queries.py : SQL statements used for inserts
- requirements.txt : packages used

## Overview / How it works

1. **Stage**: Stage events and songs data from S3 into Redshift staging tables using `StageToRedshiftOperator`.
   - Operator builds and executes a COPY command against Redshift.
2. **Load fact**: `LoadFactOperator` executes the SQL that populates the `songplays` fact table from staging tables.
3. **Load dimensions**: `LoadDimensionOperator` populates 4 dimension tables (users, songs, artists, time). Supports truncate-insert pattern.
4. **Data quality**: `DataQualityOperator` runs checks (SQL + expected results) against Redshift and fails the DAG if checks don't pass.

## Prerequisites
- AWS account with an S3 bucket containing `log-data` and `song-data` (copy from Udacity s3://udacity-dend/...)
- Redshift Serverless or provisioned cluster
- Airflow environment with AWS & Redshift connections (`aws_credentials` and `redshift`)
- Ensure Airflow has the AWS provider package installed

## How to use
1. Upload files into Airflow project (dags + plugins). Restart webserver/scheduler if needed.
2. Update connection IDs and S3 bucket names in `dags/sparkify_dag.py` and operator args.
3. Trigger DAG from Airflow UI.

## Notes
- The Stage operator uses S3Hook to obtain AWS credentials. In production, prefer IAM roles for Redshift COPY instead of passing keys.
- For local testing, use docker-compose with an Airflow image and configure connections.

