from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.empty import EmptyOperator
from plugins.operators.stage_redshift import StageToRedshiftOperator
from plugins.operators.load_fact import LoadFactOperator
from plugins.operators.load_dimension import LoadDimensionOperator
from plugins.operators.data_quality import DataQualityOperator
from plugins.helpers.sql_queries import SqlQueries

default_args = {
    'owner': 'sparkify',
    'depends_on_past': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=5),
    'email_on_retry': False
}

with DAG(
    'sparkify_etl',
    start_date=datetime(2023,1,1),
    default_args=default_args,
    schedule_interval='@hourly',
    catchup=False
) as dag:

    start = EmptyOperator(task_id='Begin_execution')
    end = EmptyOperator(task_id='Stop_execution')

    stage_events = StageToRedshiftOperator(
        task_id='Stage_events',
        table='staging_events',
        s3_bucket='your-bucket',
        s3_key='log-data',
        redshift_conn_id='redshift',
        aws_credentials_id='aws_credentials',
        json_path='s3://your-bucket/log_json_path.json'
    )

    stage_songs = StageToRedshiftOperator(
        task_id='Stage_songs',
        table='staging_songs',
        s3_bucket='your-bucket',
        s3_key='song-data',
        redshift_conn_id='redshift',
        aws_credentials_id='aws_credentials'
    )

    load_songplays = LoadFactOperator(
        task_id='Load_songplays_fact_table',
        redshift_conn_id='redshift',
        sql=SqlQueries.songplay_table_insert
    )

    load_songs = LoadDimensionOperator(
        task_id='Load_song_dim_table',
        table='songs',
        redshift_conn_id='redshift',
        sql=SqlQueries.song_table_insert,
        truncate=True
    )

    load_users = LoadDimensionOperator(
        task_id='Load_user_dim_table',
        table='users',
        redshift_conn_id='redshift',
        sql=SqlQueries.user_table_insert,
        truncate=True
    )

    load_artists = LoadDimensionOperator(
        task_id='Load_artist_dim_table',
        table='artists',
        redshift_conn_id='redshift',
        sql=SqlQueries.artist_table_insert,
        truncate=True
    )

    load_time = LoadDimensionOperator(
        task_id='Load_time_dim_table',
        table='time',
        redshift_conn_id='redshift',
        sql=SqlQueries.time_table_insert,
        truncate=True
    )

    dq_checks = [
        {'check_sql': "SELECT COUNT(*) FROM songplays WHERE playid IS NULL", 'expected_result': 0},
        {'check_sql': "SELECT COUNT(*) FROM users WHERE userid IS NULL", 'expected_result': 0}
    ]

    run_quality = DataQualityOperator(
        task_id='Run_data_quality_checks',
        redshift_conn_id='redshift',
        checks=dq_checks
    )

    start >> [stage_events, stage_songs] >> load_songplays
    load_songplays >> [load_songs, load_users, load_artists, load_time] >> run_quality >> end
