class SqlQueries:
    songplay_table_insert = ("""
    INSERT INTO songplays (playid, start_time, userid, level, songid, artistid, sessionid, location, user_agent)
    SELECT md5(events.sessionid || events.start_time) playid,
           events.start_time, events.userid, events.level, songs.song_id, songs.artist_id,
           events.sessionid, events.location, events.useragent
    FROM (
        SELECT TIMESTAMP 'epoch' + ts/1000 * INTERVAL '1 second' AS start_time, *
        FROM staging_events
        WHERE page = 'NextSong'
    ) events
    LEFT JOIN staging_songs songs
        ON events.song = songs.title
        AND events.artist = songs.artist_name
        AND events.length = songs.duration;
    """)

    user_table_insert = ("""
    SELECT distinct userid, firstname, lastname, gender, level
    FROM staging_events
    WHERE userid IS NOT NULL;
    """)

    song_table_insert = ("""
    SELECT distinct song_id, title, artist_id, year, duration
    FROM staging_songs;
    """)

    artist_table_insert = ("""
    SELECT distinct artist_id, artist_name, artist_location, artist_latitude, artist_longitude
    FROM staging_songs;
    """)

    time_table_insert = ("""
    SELECT distinct start_time, extract(hour from start_time), extract(day from start_time),
           extract(week from start_time), extract(month from start_time),
           extract(year from start_time), extract(weekday from start_time)
    FROM songplays;
    """)
