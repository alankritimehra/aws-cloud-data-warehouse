from airflow.models import BaseOperator
from airflow.providers.amazon.aws.hooks.s3 import S3Hook
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.utils.decorators import apply_defaults

class StageToRedshiftOperator(BaseOperator):

    ui_color = '#358140'
    template_fields = ('s3_key', 'json_path')
    copy_sql = """COPY {table}
        FROM '{s3_path}'
        ACCESS_KEY_ID '{access_key}'
        SECRET_ACCESS_KEY '{secret_key}'
        FORMAT AS JSON '{json_path}'
        REGION '{region}';"""

    @apply_defaults
    def __init__(self,
                 redshift_conn_id='',
                 aws_credentials_id='',
                 table='',
                 s3_bucket='',
                 s3_key='',
                 json_path='auto',
                 region='us-west-2',
                 *args, **kwargs):

        super(StageToRedshiftOperator, self).__init__(*args, **kwargs)
        self.table = table
        self.redshift_conn_id = redshift_conn_id
        self.aws_credentials_id = aws_credentials_id
        self.s3_bucket = s3_bucket
        self.s3_key = s3_key
        self.json_path = json_path
        self.region = region

    def execute(self, context):
        self.log.info(f"Clearing data from Redshift table {self.table}")
        redshift = PostgresHook(postgres_conn_id=self.redshift_conn_id)
        redshift.run(f"DELETE FROM {self.table}")

        s3_path = f"s3://{self.s3_bucket}/{self.s3_key}"
        aws_hook = S3Hook(aws_conn_id=self.aws_credentials_id)
        creds = aws_hook.get_credentials()
        rendered_key = self.s3_key.format(**context['ds_obj'].__dict__)
        s3_path = f"s3://{self.s3_bucket}/{rendered_key}"

        formatted_sql = StageToRedshiftOperator.copy_sql.format(
            table=self.table,
            s3_path=s3_path,
            access_key=creds.access_key,
            secret_key=creds.secret_key,
            json_path=self.json_path,
            region=self.region
        )
        self.log.info(f"Running COPY: {formatted_sql}")
        redshift.run(formatted_sql)
