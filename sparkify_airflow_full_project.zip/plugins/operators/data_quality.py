from airflow.models import BaseOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.utils.decorators import apply_defaults

class DataQualityOperator(BaseOperator):

    ui_color = '#89DA59'

    @apply_defaults
    def __init__(self, redshift_conn_id='', checks=[], *args, **kwargs):
        super(DataQualityOperator, self).__init__(*args, **kwargs)
        self.redshift_conn_id = redshift_conn_id
        self.checks = checks

    def execute(self, context):
        redshift = PostgresHook(postgres_conn_id=self.redshift_conn_id)
        for check in self.checks:
            sql = check.get('check_sql')
            expected = check.get('expected_result')
            records = redshift.get_records(sql)
            if len(records) < 1 or len(records[0]) < 1:
                raise ValueError(f"Data quality check failed. SQL returned no results: {sql}")
            result = records[0][0]
            if result != expected:
                raise ValueError(f"Data quality check FAILED: {sql}. Expected {expected}, got {result}")
            self.log.info(f"Data quality check PASSED: {sql}")
