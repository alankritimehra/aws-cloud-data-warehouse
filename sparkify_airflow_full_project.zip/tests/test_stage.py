def test_stage_operator_importable():
    from plugins.operators.stage_redshift import StageToRedshiftOperator
    assert StageToRedshiftOperator is not None
